Follow the following steps to see a demo of generating on simulation data.

First, make sure you correctly configurate PSFgenerator with your MATLAB.
(available at http://bigwww.epfl.ch/algorithms/psfgenerator/)

Then follow the parameters specified in ./Utils/PSF_calcu_5.png to generate a 3D PSF stack, and save the PSF stack with variable name 'psf' and save with file name PSF_calcu_5.png under folder Utils.
Record a series of empty frames from dark counts or with background from your optical setup, makes rue the frame size follows 512x512 pixels, and name it as 'EmptyMovie11.tif', put it under the main folder.

Run filaMain_get3DfilamentsSimulation.m to generate a noise free movie of filaments.
Run AggreMain_get3DAggregatesSimulation.m to generate anise free movie of aggregates.
Run LastStep_Combine_Main_addNoiseBackGround.m to generate a combined movie with added noise and adjusted SNR as specified in the script.
