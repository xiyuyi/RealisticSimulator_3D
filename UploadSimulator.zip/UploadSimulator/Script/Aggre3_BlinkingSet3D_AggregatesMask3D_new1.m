clear all
close all
load AggregatesMask3D_new1_Labeled.mat
load Syn_Bcurve1k.mat
load randseed2015Oct7_2.mat s
rng(s)
FPspec.tauOn = 0.038;
FPspec.tausOff = 0.0012;
FPspec.sigsOff = 0.001;
FPspec.taulOff = 1;
FPspec.taumOff = 0.063;
FPspec.taubst = 0.2;
FPspec.BleaC = Bcurve;%bleaching curve
FPspec.BritD = rand(Feature.LabN, 1).*0.2 +0.8; %brightness distribution is 0.8 to 1.

MovieSpec.tExpo  = 0.05;
MovieSpec.Nframe = 1000;
MovieSpec.tTotal = MovieSpec.tExpo*MovieSpec.Nframe;
MovieSpec.Slevel = 5000;%5 counts per ms per emitter at Pure On time..
MovieSpec.Blevel = 0.02; %2% background level.

         LabD = Feature.LabD;
         LabU = Feature.LabU;
      EmiLocs = Feature.EmiLocs;
           UL = Feature.UL;
        siteD = Feature.siteD;
         LabP = Feature.LabP;
         LabN = Feature.LabN;
       
        tExpo = MovieSpec.tExpo;
       Nframe = MovieSpec.Nframe;
       tTotal = MovieSpec.tTotal;
       Slevel = MovieSpec.Slevel;
       Blevel = MovieSpec.Blevel;
       
        tauOn = FPspec.tauOn;
      gausOff = FPspec.tausOff;
      sigsOff = FPspec.sigsOff;
      taulOff = FPspec.taulOff;
      taumOff = FPspec.taumOff;
       taubst = FPspec.taubst;
        BleaC = FPspec.BleaC;
        BritD = FPspec.BritD;
        
%% calculate initial on-off series       
for i0 = 1:LabN
  disp(['calculate ',num2str(i0),'/',num2str(LabN),' on-off series']);
  [info, comS]=getFPblinking(FPspec.tauOn, FPspec.taulOff, FPspec.taumOff, FPspec.tausOff, FPspec.sigsOff, FPspec.taubst, tTotal);
  eval(['info',num2str(i0),'=info;'])
  eval(['comS',num2str(i0),'=comS;'])
end


%% modify On-off series to enable bleaching.
AcPop = floor(Bcurve.*LabN);  % total number of active emitters as a function of time.
BlPop = LabN - AcPop;% total number of bleached emitters
X = [BlPop; [1:Nframe]]; % total number of bleached emitters, indexed in second row.
Xtrans = [0, X(1, 2:end) - X(1, 1:end - 1)]; %changing indexes of total number of bleached emitters.
TransInds = find(Xtrans(1, :) > 0);%index where total number of bleached emitters changes.
TransI = [1, BlPop(TransInds(1 : end - 1))] + 1;%same size as TransInds, at transition frame index given by TransInds, gives the starting index of emitters to bleach. 
TransE = BlPop(TransInds);%same size as TransInds, at transition frame index given by TransInds, gives the ending index of emitters to bleach. 
Inds=sortrows([[1 : LabN]', rand(LabN, 1)], 2); Inds = Inds(:, 1);  % give emitters random indexes, so the emitters are programmably bleached in random order.

for i0 = 1:length(TransInds) % go over all transition frames.
    frameInd = TransInds(i0); % get the frame index of that transition frame.
    t = tExpo*(frameInd - 1); % get the elapsed time for that given frame.
    for i1 = TransI(i0) : TransE(i0) % go over the emitters that suppose to be bleached within this transition frame
        %% bleach the emitter
        eval(['comS = comS',num2str(Inds(i1)),';'])% take the i1th emitter in the random ordering.
        %now put bleaching time point into this comS series.  
        comS = Bleach(comS,t);     
        eval(['comS',num2str(Inds(i1)),' = comS;'])% modify the i1th emitter in the random ordering.  
        comS = []; a1 = [];
    end
end
        
%% calcualte Intensity Trajectories.
for i0 = 1:LabN
    disp(['calculate ',num2str(i0),'/',num2str(LabN),' Intensity Trajectories']);
    eval(['comS = comS',num2str(i0),';'])
    [IntSeries,para]=getIntProfileFP(comS, tExpo, Nframe, Slevel*BritD(i0));
    eval(['IntSeries',num2str(i0),'=IntSeries;'])
    eval(['para',num2str(i0),'=para;'])
end

save BlinkingSet3D_AggregatesMask3D_new1.mat
%% Now ConstructMovie (without SNR, noise, background, only blinking with intensity ratios)
 
