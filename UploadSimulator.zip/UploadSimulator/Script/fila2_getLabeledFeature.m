clear all;
load randseed3.mat s
rng(s)
fname = 'StaticPattern3D_20filamentsSet1';
eval(['load ',fname,'.mat'])
Feature.LabD = 50 ; %Labeling density (# per 1000 nm)
Feature.LabU = 7;%LabelingUncertainty (nm) (standard deviation of the gaussian distribution)
Feature.EmiLocs = []; %actual emitter location; to be assigned.
Feature.UL = 16; %Unit Length Before Binning, (nm), It's not the strignLinkLength.
Feature.siteD = 1/StringLinkLength/Feature.UL*1000; %# availabe labeling site density per 1000 nm.

Feature.LabP = Feature.LabD/Feature.siteD; %percentage of labeling site to be labeled.

Feature.LabN = floor(Feature.LabP*(StringNumber*StringLinkNumber)); %number of labeling site to be labeled in this feature.
locwInds = sortrows([loc,rand(StringNumber*StringLinkNumber, 1)], 4);% put random indexes for all the available labeling site.
loc = locwInds(1:Feature.LabN, :);% so these are targeted labeling sites.
loc(:, 1:3) = loc(:, 1:3) + Feature.LabU/Feature.UL.*randn(Feature.LabN, 3);
loc((loc(:,3)<1),:)=[];

Feature.EmiLocs = floor(loc) + 1;
Feature.LabN = length(Feature.EmiLocs(:,1));

eval(['save ',fname,'_Labeled.mat Feature'])



