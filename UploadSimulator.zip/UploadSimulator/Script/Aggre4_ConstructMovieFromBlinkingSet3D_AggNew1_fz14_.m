%for Loop for convolutiontest
clear all
load PSF_calcu_5.mat psf
load AggregatesMask3D_new1_Labeled
load BlinkingSet3D_AggregatesMask3D_new1.mat
[xdim, ydim, zdim]=size(psf);
xw = (xdim-1)/2;
yw = (ydim-1)/2;
zw = (zdim-1)/2;
psf = psf./sum(sum(psf(:,:,zw+1)));
LabN = Feature.LabN;
loc = Feature.EmiLocs;
zChosen = 80

    xstaS=max(loc(:,1)-xw , 1); % starting edge on im, x dimension.
    xendS=min(loc(:,1)+xw, 2560);% ending edge on im, x dimension
    
    ystaS=max(loc(:,2)-yw, 1); % starting edge on im, y dimension.
    yendS=min(loc(:,2)+yw, 2560);% ending edge on im, y dimension
    
    xsta1S = xw - (loc(:,1) - xstaS(:)) + 1;% starting edge on PSF matrix, x dimension
    xend1S = xw + (xendS(:) - loc(:,1) )+ 1;% ending edge on PSF matrix, x dimension
    
    ysta1S = yw - (loc(:,2) - ystaS(:)) + 1; % starting edge on PSF matrix, y dimension
    yend1S = yw + (yendS(:) - loc(:,2) )+ 1;% ending edge on PSF matrix, y dimension.
    
    zInds = zw + zChosen - loc(:,3);% z index on PSF matrix to extract for each emitter location.



for i1=1:MovieSpec.Nframe
    im = zeros(2560, 2560);
    disp(['construct ',num2str(i1),'/',num2str(Nframe),' Movie']);
    for i0 = 1:Feature.LabN
      
        tp = psf(xsta1S(i0):xend1S(i0), ysta1S(i0):yend1S(i0), zInds(i0));
        eval(['I = IntSeries',num2str(i0),'(i1);'])   
        im(xstaS(i0):xendS(i0),ystaS(i0):yendS(i0)) = im(xstaS(i0):xendS(i0),ystaS(i0):yendS(i0)) + tp.*I; 
        
    end
    imb = im;
    imbb = uint16(binPixel(imb,10)); %this is simulated camera sensor capture before EM gain
    imwrite(imbb, 'BlinkingSet3D_AggregatesMask3D_new1Z14.tif', 'WriteMode','Append');
end


