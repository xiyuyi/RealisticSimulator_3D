clear all
addpath ./Utils
load randseed2015Oct7.mat
rng(s)
close all
m=zeros(2560,2560,101);
mSum=m;
Hw=100;
N = 20; % number of aggregates
locC = zeros(N, 3);% center locations of each aggregate.
locC = [1000+rand(N,2).*600, 51 - (rand(N,1)-0.5).*90];
dis = rand(N).*5 + 2; % diameter of each aggregate.
[a, b, c] = meshgrid([-25:25]);
d = sqrt(a.^2 + b.^2 + c.^2);
e = [a(:), b(:), c(:), d(:), [1:length(a(:))]'];
locs = [];
for i0 = 1:N
   disp(['putting down aggregates #',num2str(i0),'/20'])
    
    vec = e(find(d(:)<dis(i0)), : ); %#ok<FNDSB>
    l = [vec(:,1) + locC(i0, 1), vec(:,2) + locC(i0, 2), vec(:,3) + locC(i0, 3)];
    locs = [locs; l];
    1;
    
end

locs = floor(locs)+1;
loc = locs;
%organize information:
Agg.aggN = N; % number of aggregates.
Agg.aggCenter = locC; % centers of aggregates.
Agg.loc = loc; %locations of emitters in aggregates.
eval(['save AggregatesMask3D_new1.mat loc Agg'])
clear all
load  AggregatesMask3D_new1.mat loc
load PSF_calcu_4.mat
stepLength=16;%z-step depth
EmiDemoN = 200; % only use 1000 emitters to calculate this demo.
fnameHead = 'AggreTest1'
xy_zoomIn_zoomOut_Demo(loc,psf,stepLength,EmiDemoN,fnameHead)