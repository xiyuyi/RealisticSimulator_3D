clear all;
addpath Utils
load randseed2.mat % this was the random number seed used to generate the simulation used in the paper. No need to keep it in this way.
rng(s)
StringNumber = 20;
StringLinkNumber = 2000; 
StringLinkLength=0.4;
visualization=0;
zw = 50;
locIniList = [1000+rand(StringNumber,2).*300, 51 - (rand(StringNumber,1)-0.5).*90];
N = StringLinkNumber;
locs = [];
for i0 = 1:StringNumber
    disp(['putting down fillaments #', num2str(i0),'/20'])
    
loc=getACurve3D(StringLinkNumber, StringLinkLength, 0.005, 2, 0.00001, 0.08)+ones(2000,1)*locIniList(i0,:);
locs = [locs; loc];
end
locs(:, 1:2) = floor(locs(:,1:2)) + 1;
locs(:,  3 ) = (floor(locs(:,3)) + 1);


if visualization
figure(1);plot3(locs(:,1),locs(:,2),locs(:,3),'.')
figure(2);plot3(locs(:,1),locs(:,2),locs(:,3),'.');axis([1,2560,1,2560,0,zw*2+1]);
end

loc = locs;
save StaticPattern3D_20filamentsSet1.mat loc String*
clear all
close all
load StaticPattern3D_20filamentsSet1.mat loc 
load PSF_calcu_5.mat
stepLength=16;%z-step depth
EmiDemoN = 500; % only use 1000 emitters to calculate this demo.
fnameHead = 'filaTest1'
xy_zoomIn_zoomOut_Demo(loc,psf,stepLength,EmiDemoN,fnameHead);
