clear all;
rng(0)
fname = 'AggregatesMask3D_new1';
% this program is designed for piecewise constant, so it's talking about
% densityes in 2 dimension area.
eval(['load ',fname,'.mat'])
TotalLocationN = length(loc(:,1));
Feature.LabD = 50^3 ; %Labeling density (# per 1000^3 nm^3); so keep the same line density.
Feature.LabU = 70;%LabelingUncertainty (nm) (standard deviation of the gaussian distribution)
Feature.EmiLocs = []; %actual emitter location; to be assigned.
Feature.UV = 16^3; %Unit volume Before Binning(single pixel area), (nm^2)
Feature.UL = 16; %Unit length before binning(single pixel length)
Feature.siteD = 1/Feature.UV*1000^3; %# availabe site Density per 1000^2 nm^2. because it's continouse locations on piecewise constants.
Feature.LabP = Feature.LabD/Feature.siteD; %percentage of labeling site to be labeled. 

Feature.LabN = floor(Feature.LabP*TotalLocationN); %number of labeling site to be labeled in this feature.
locwInds = sortrows([loc,rand(TotalLocationN, 1)], 4);% put random indexes for all the available labeling site.
loc = locwInds(1:Feature.LabN, :);% so these are targeted labeling sites.
loc(:, 1:2) = loc(:, 1:2) + Feature.LabU/Feature.UL.*randn(Feature.LabN, 2);
Feature.EmiLocs = floor(loc) + 1;

eval(['save ',fname,'_Labeled.mat Feature Agg'])

im=zeros(2560,2560);
loc = Feature.EmiLocs
figure;
plot3(loc(:,1),loc(:,2),loc(:,3),'.')


