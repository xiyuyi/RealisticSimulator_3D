clear all
close all
load randseed2015Oct7_3.mat
rng(s)
fname1 = 'BlinkingSet3D_20filamentsSet1Z14';
fname2 = 'BlinkingSet3D_AggregatesMask3D_new1Z14';
fname3 = 'EmptyMovie11';

%fname4 = 'BlinkingSet3D_20filamentsSet1Z14_Agg3DNew1Z80_UponCapture';
fname5 = 'BlinkingSet3D_20filamentsSet1Z14_Agg3DNew1Z14_afterEMwithBg';
%eval(['delete ',fname4,'.tif'])
eval(['delete ',fname5,'.tif'])

bg = 300*0.2;
SigLevel_noEM = 300; %300 count signal leve without EM.

for i0 = 1:1000
    1000-i0
    im1 = imread([fname1,'.tif'],'Index',i0);%signal frome filaments.
    im2 = imread([fname2,'.tif'],'Index',i0);%signal frome aggregates.
     bg = imread([fname3,'.tif'],'Index',i0);
     im = im1 + im2; %additive signal.
     
   cap = (poissrnd(double(im)));% add poissNoise to the Image.
   EM = cap.*(600/300) + double(bg(1:256,1:256));
   %imwrite(uint16(cap), [fname4,'.tif'],'writemode','append');
   imwrite(uint16(EM), [fname5,'.tif'],'writemode','append');
   
1;
   

end


