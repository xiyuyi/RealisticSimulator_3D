function xy_zoomIn_zoomOut_Demo(locs,psf,stepLength,EmiDemoN,fnameHead)
rng(100)
[xdim, ydim, zdim]=size(psf);
xw = (xdim-1)/2;
yw = (ydim-1)/2;
zw = (zdim-1)/2;
disp(['pick locations....'])
Inds = floor(rand(2000,1).*length(locs(:,1)))+1;
loc = locs(Inds,:);

im = zeros(2560, 2560, zw);


for i0 = 1:EmiDemoN
    disp(['putting emitters, ', num2str(EmiDemoN-i0),' emitters remained.']);
    
    xstaS=max(loc(i0,1)-xw , 1);
    xendS=min(loc(i0,1)+xw, 2560);
    
    ystaS=max(loc(i0,2)-yw, 1);
    yendS=min(loc(i0,2)+yw, 2560);
    
    zstaS=max(loc(i0,3)-zw, 1);
    zendS=min(loc(i0,3)+zw, zw);
    
    xsta1S = xw - (loc(i0,1) - xstaS) + 1;
    xend1S = xw + (xendS - loc(i0,1) )+ 1;
    
    ysta1S = yw - (loc(i0,2) - ystaS) + 1;
    yend1S = yw + (yendS - loc(i0,2) )+ 1;
    
    zsta1S = zw - (loc(i0,3) - zstaS) + 1;
    zend1S = zw + (zendS - loc(i0,3)) + 1;

    tp = psf(xsta1S:xend1S, ysta1S:yend1S, zsta1S:zend1S);
    im(xstaS:xendS,ystaS:yendS,zstaS:zendS) = im(xstaS:xendS,ystaS:yendS,zstaS:zendS) + tp; 
end

vidObj = VideoWriter(['zoomInOutDemo_',fnameHead,'_',num2str(EmiDemoN),'_EmitterDemo.avi']);
open(vidObj);
figure(1)
for i0 = 1:100
    disp(['demo layer #',num2str(i0),'/100'])
x = im(:,:,i0);
x = binPixel(x, 10);
figure(1);imshow(x,[])
colormap(pink)
t=text(5,5,[num2str((i0-51)*stepLength),' nm from focal plane']);
set(t,'fontSize',20,'Color',[1,1,1])

drawnow;
currFrame = getframe;
writeVideo(vidObj,currFrame);

end
end