function [IntSeries,para]=getIntProfileFP(comS, tExpo, Nframe, SNR)
%randomly choose the initlia phase to be either on or off; and construct time series.
% SNR is defined interms of # of counts per s.
%comS = [timS; tauS; phaS];
SNRrel=SNR*tExpo;

% define the complete insert time points of binning
timI = [tExpo : tExpo : tExpo*Nframe];
tauI = zeros(1,Nframe);
phaI = ones(1,Nframe).*2;
comI = [timI; tauI; phaI];
% perform insertion to perform the total complete vector.
comI = sortrows([comS'; comI'])';

% modify the inserted phase and taui after insertion.
timT = comI(1, :); 
tauT = comI(2, :); 
phaT = comI(3, :);

% step1. modify phase series
% calculate the index that suppose to be on or off state.
preOn = find(phaT==1); %on state index,  before insertion.
preOf = find(phaT==0); %off state index, before insertion.
preFr = find(phaT==2); %the index of frame cut position.
% the index series above should have the same size.
L = length(preOf);

      phaT(1:preOf(1)) = 0; %initial phase is off;
      for i0=1:L-1
      phaT(preOf(i0)+1 : preOn(i0))  = 1;
      phaT(preOn(i0)+1 : preOf(i0+1))= 0;
      end
      phaT(preOf(L)+1  : end)   = 0;    

%step2. modify taui series.
tauT(2:end) = timT(2:end)-timT(1:end-1);
    tauT(1) = timT(1); 
comT = [timT; tauT; phaT];

% construct intensity ratios
IntSeries=[1,Nframe];
% starting frame:
tiOn = sum(comT(2,1:preFr(1)).*comT(3,1:preFr(1)));
%tiAl = sum(comT(2,1:preFr(1)));
tiAl = tExpo;

IntSeries(1) =  tiOn/tiAl;
% second to last frames
 for i0 = 2 : Nframe;   
  tiOn = sum(comT(2,preFr(i0-1)+1:preFr(i0)).*comT(3,preFr(i0-1)+1:preFr(i0)));
  %tiAl = sum(comT(2,preFr(i0-1)+1:preFr(i0)))
  tiAl = tExpo;
  IntSeries(i0) =  tiOn/tiAl;
 end

IntSeries = IntSeries.*SNRrel;
para.comT=comT;
para.comI=comI;
para.preFr=preFr;
para.preOn=preOn;
para.preOf=preOf;
1;
end