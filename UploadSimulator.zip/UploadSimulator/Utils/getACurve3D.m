function loc=getACurve(L, r0, P1, P2, P3, P4) 
% halfway
% L is the total number of junction point on the rope. 
% r0 is the distance between the junction points on the rope, interms of unit length (2D).
% P1 Average tilt angle per link(degree). (more directional preference, give over all long scale curvature)
% P2 Average second tilt angle per link(degree). (less directional preference, give small local regional curvature)
    % randomly compute a length of the starting piece of chain. 
    % in the range of 500 to 900 in terms of pixel index for x(y) dimentions
    staloc = [0, 0, 0];
    rr = rand(1);% Then choose a random direction of the starting piece of the chain.
    b(1, :) = [0, 0, 0];
    % the ending point of the starting chain will thus be destributed along
    % a circle.
    phib = pi/2; % put a random purterbation to the initial angle in z.
    thetab = rr.*2.*pi+pi/2+2*(rand(1)-0.5).*pi/180*20; % put a random purterbation to the initial angle.
    curC = 0;% initial angle list in z.
    cur = 0;% set back to initial value of the orientation of the first chain.
    for i0=2:L;% loop over all the linkers on the curve, one by one.
        cur0 = (rand(1)-0.49)*2*pi/180*P1;% tilt the angle a little.
        cur = cur+(cur0);% angle is change cumulated, the angle of this chain is changed based on the angle of the previouse chain.
        cur0C = (rand(1)-0.49)*2*pi/180*P3;% tilt the angle a little, in z.
        curC = curC+(cur0C);% angle is change cumulated, the angle of this chain is changed based on the angle of the previouse chain.
        theta = (rand(1)-0.501)*2.*pi/180*P2+cur;% now tilt the angle further by a little(theta).
        phi = (rand(1)-0.5001)*2.*pi/180*P4+curC;% now tilt the angle further by a little(phi).
       
        
        %b(i0,:) = b(i0-1,:) + r0.*[sin(theta+thetab), cos(theta+thetab)];
        %should change this one..to 3D direction tilt, from thetab and phib
        thetab=theta+thetab;
        phib = phi + phib;
        % now calculate location vector based on thetab and phib
        dr = r0.*[sin(phib)*sin(thetab),sin(phib)*cos(thetab),cos(phib)];
        b(i0,:) = b(i0-1,:) + dr;
    end
    % give half-half probability for a mirrow flip about line of x=y 
    if rand(1)>0.5; loc=b; else loc=b*[0,1,0;1,0,0;0,0,1]; end
    
    %place linklength constraints on the curve.
%     for i1 = 2:L
%       d = (loc(i1-1, :) - loc(i1, :)).*(1 - r0/norm(loc(i1-1, :) - loc(i1, :)));
%       loc(i1, :) = loc(i1, :) + d;
%     end
return 
